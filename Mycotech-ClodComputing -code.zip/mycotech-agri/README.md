# 🍄 MycoTech Agri — Cloud-Native AI-IoT Mushroom Monitoring Platform

Full-stack Python implementation of the architecture in **MycoTech_Cloud_Project.pdf**
(Cloud Computing Mandatory Project — Team: Shashank Roy, Rupali Pragati, Member 3).

> Farmers lose 30–40% of mushroom crop to manual, data-less monitoring. MycoTech replaces
> paper logs with IoT sensors → Dockerized API on AWS → AI scoring → alerts within minutes.

## Architecture (PDF §4–6)

```
Farmer App / IoT Sensors → Route 53 → ALB (HTTPS) → ECS Fargate (API + AI Worker)
                                                   → RDS PostgreSQL Multi-AZ
                                                   → S3 (raw data + backups)
Telemetry: ECS → CloudWatch → SNS alerts | Images: ECR → ECS | IaC: Terraform
Region: ap-south-1 (Mumbai) | VPC 10.0.0.0/16 | Auto-scaling @ 60% CPU
```

## Stack

| Layer | Local (this repo) | AWS (production) |
|---|---|---|
| Frontend | Modern dashboard (HTML/CSS/JS, served by FastAPI) | Same, behind ALB / S3+CloudFront |
| Backend API | **FastAPI (Python 3.11)** + Uvicorn | ECS Fargate, `mycotech/api:1.0` from ECR |
| AI Worker | In-API scoring (`mycotech-risk-v1`) | Separate ECS task (1 vCPU / 2 GB) |
| Database | SQLite (zero-setup) | RDS PostgreSQL Multi-AZ (20 GB, KMS) |
| Monitoring | `/api/metrics/sla` + middleware timings | CloudWatch + SNS |

## Quick Start

```bash
cd mycotech-agri
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
# Open http://localhost:8000  |  Docs: http://localhost:8000/docs  |  Health: /health
```

**Docker (PDF §6):**
```bash
docker compose up --build     # API + AI worker + PostgreSQL
docker build -t mycotech/api:1.0 .
```

## Features

- **Live dashboard** — 4 demo farms (Purnia, Patna, Gaya, Bhagalpur), auto-refreshing KPIs, canvas trend chart
- **IoT ingestion** — `POST /api/readings` (sensors every 30s in prod; built-in simulator in demo)
- **AI scoring** — health score, contamination risk, predicted yield (kg/cycle), recommendations
  (ideal fruiting: 22 °C, 88 % RH, 800 ppm CO₂, 65 % substrate moisture)
- **Alerts** — S1/S2 incidents generated on WARNING/CRITICAL conditions (SNS on AWS)
- **Failure demo** — *Inject Failure / Anomaly* button → watch risk spike & alerts → *Recover* (ECS self-healing / TTR flow)
- **SLA/TTR panel** — live P95 from middleware vs targets below

## SLA & TTR (PDF §3, §8–9)

| Metric | Target | Projected/Observed |
|---|---|---|
| Availability | 99.5 %/mo (~3.6 h downtime) | 99.8 % |
| API response | P95 < 2,000 ms | 650 ms |
| RTO / RPO | 5 min / 5 min | RDS backups + S3 copy |
| TTR | 10 min (Detect 1 + Diagnose 2 + Recover 2 + Verify 1) | **6 min** |
| Throughput | 100 users, 50 req/s | 85 req/s |

Load test: `pip install locust && locust -f locustfile.py --host http://localhost:8000`

## API

| Endpoint | Description |
|---|---|
| `GET /health` | ECS/ALB health check |
| `GET /api/farms` · `GET /api/readings/latest` | Farms & latest AI-scored readings |
| `GET /api/readings?farm_id=&limit=` | Sensor history |
| `POST /api/readings` | Ingest one IoT reading → AI-scored |
| `GET /api/predictions/{farm_id}` | Health, contamination risk, yield, recommendations |
| `GET /api/alerts` · `GET /api/metrics/sla` · `GET /api/architecture` | Alerts, SLA/TTR, pipeline |
| `POST /api/simulate/anomaly/{farm_id}` · `/recover/{farm_id}` | Failure & recovery demo |

## Cost (PDF §10)

~**₹5,000/month**: Fargate ₹2,000 + RDS ₹1,500 + ALB ₹700 + other ₹800.
Business extension: SaaS at ₹199–499/farm/month to FPOs & mushroom farmers across Bihar.

## Security

Least-privilege IAM, DB in private subnets (443 only from ALB), Secrets Manager (no
credentials in code/images), KMS encryption at rest + TLS in transit.

## Project Structure

```
mycotech-agri/
├── app/main.py            # FastAPI API + AI scoring + simulator + SLA middleware
├── app/static/index.html  # Modern frontend dashboard (single-file, no CDN)
├── Dockerfile             # python:3.11-slim, EXPOSE 8000 (PDF §6)
├── docker-compose.yml     # API + AI worker + PostgreSQL
├── terraform/main.tf      # AWS IaC sketch (VPC/ECS/RDS/S3/CloudWatch)
├── locustfile.py          # Load test (PDF §9)
└── requirements.txt
```
