"""Load test for PDF §9: 100 concurrent users, 50 req/s, 10k records.
Run:  pip install locust && locust -f locustfile.py --host http://localhost:8000
Targets: P95 < 2000ms, Availability 99.5%, Throughput ~85 req/s
"""
from locust import HttpUser, task, between
import random

class FarmerUser(HttpUser):
    wait_time = between(0.5, 2)
    @task(3)
    def latest(self): self.client.get("/api/readings/latest")
    @task(2)
    def history(self): self.client.get("/api/readings?farm_id=farm-purnia-01&limit=30")
    @task(1)
    def ingest(self):
        self.client.post("/api/readings", json={"farm_id":"farm-purnia-01","temperature":round(random.uniform(20,25),1),"humidity":round(random.uniform(82,94),1),"co2":random.randint(600,1200),"light":300,"moisture":round(random.uniform(58,72),1)})
    @task(1)
    def sla(self): self.client.get("/api/metrics/sla")
