# MycoTech Agri — AWS IaC sketch (PDF §5-7) | Region ap-south-1 | VPC 10.0.0.0/16
# Full apply needs AWS account; this maps 1:1 to the architecture diagram (slide 6).
terraform { required_providers { aws = { source = "hashicorp/aws", version = "~> 5.0" } } }
provider "aws" { region = "ap-south-1" }

resource "aws_vpc" "main" { cidr_block = "10.0.0.0/16" tags = { Name = "mycotech-vpc" } }
# Public subnet (ALB) + Private subnets AZ-a/AZ-b (ECS + RDS) — add aws_subnet resources per slide 6.

resource "aws_ecr_repository" "api" { name = "mycotech/api" image_scanning_configuration { scan_on_push = true } }
resource "aws_ecs_cluster" "main" { name = "mycotech-cluster" }
# aws_ecs_task_definition: API 0.5 vCPU/1GB, AI worker 1 vCPU/2GB (PDF §7), image from ECR, logs -> CloudWatch
# aws_lb (ALB, HTTPS 443) + aws_lb_target_group health check /health
# aws_db_instance: RDS PostgreSQL, Multi-AZ, 20GB, KMS-encrypted, private subnets only
# aws_s3_bucket: raw sensor data + backups, KMS encryption
# aws_cloudwatch_metric_alarm: P95 latency > 2000ms & unhealthy hosts -> aws_sns_topic alerts
# aws_appautoscaling_target: ECS scale at 60% CPU (PDF §7)
variable "db_password" { type = string, sensitive = true } # via Secrets Manager, never in code (PDF §10)
